package GameGDX.GUIData.IAction;

import GameGDX.GUIData.IChild.Component;
import GameGDX.GUIData.IChild.IActor;
import com.badlogic.gdx.scenes.scene2d.Action;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.actions.RunnableAction;

public class IEvent extends IParallel{

    public enum Kind
    {
        Init,
        Destroy
    }
    public Kind kind = Kind.Destroy;

    public IEvent()
    {
        name = "event";
    }

    @Override
    public Action Get(IActor iActor) {
        return Actions.run(()->Run(iActor));
    }

    public void Run(IActor iActor)
    {
        iActor.AddComponent(name, new Component() {
            @Override
            public void Remove() {
                Foreach(i->{
                    RunnableAction ac = (RunnableAction) i.Get(iActor);
                    ac.run();
                });
            }
        });
    }
}
