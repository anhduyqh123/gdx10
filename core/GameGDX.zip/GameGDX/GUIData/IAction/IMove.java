package GameGDX.GUIData.IAction;

import GameGDX.GUIData.IChild.IActor;
import GameGDX.GUIData.IChild.IPos;
import com.badlogic.gdx.scenes.scene2d.Action;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;

public class IMove extends IBaseAction{
    public boolean useX = true, useY = true;
    public IPos iPos = new IPos();
    public IMove()
    {
        name = "move";
    }

    @Override
    public Action Get(IActor iActor) {
        Actor actor = iActor.GetActor();
        int align = iPos.align.value;
        float x0 = actor.getX(align)+iPos.delX;
        float y0 = actor.getY(align)+iPos.delY;
        if (current) return Actions.moveToAligned(x0,y0,align,duration,iInter.value);
        iPos.getIActor = iActor.iPos.getIActor;
        if (useX) x0 = iPos.GetX();
        if (useY) y0 = iPos.GetY();
        return Actions.moveToAligned(x0,y0,align,duration,iInter.value);
    }
}
